﻿** Lenovo X220 v1.45 Modified Bios (full-blown) **

- Whitelist removal
- Unlocked AES-NI on "no-encryption" machines
- Unlocked hidden advanced menu
- Unlocked memory speed (supports DDR3 1600 and 1866)
- Disabled package c-state lock at MSR 0xE2 (for Hackintosh)
- Re-signed with custom key to get rid of 5 beeps on boot

Be careful with advanced menu. Changing some options may render your laptop unbootable!
More memory speed means more heat, 1866 MHz memory speed may increase your laptop temperature up to 5°C.

Installation process:

1. Flash the original v1.45 BIOS (8duj30us.exe)
2. Reboot the computer.
3. Open a command prompt (cmd.exe) as administrator, navigate to the Modified bios folder and run Flash.bat
4. Follow the prompts in the Phoenix UEFI WinFlash application and wait for the computer to reboot when the process completes.
5. To confirm that the modified BIOS has installed correctly, press F1 at startup to enter BIOS Setup. If the menu "Advanced" shows, then the modified BIOS has installed correctly.

These modifications were made by camiloml, BDMaster, Serg008, Oleh/Rambler and others. I'm (ValdikSS) only created hash recomputation and re-signing script and keep backporting all modifications from older to newer BIOS versions.

In case you're interested in re-signing script:
https://github.com/ValdikSS/thinkpad-shahash

---------------

ValdikSS
